<?php

//extension file do not delete

include('../database/helpdesk_queries.php');