<?php

/** 
 * simple helpdesk app
 * by Ron Valero
 * 2016111
 * MIT Licensed @2016 
  **/
 
 header('location:login.php');