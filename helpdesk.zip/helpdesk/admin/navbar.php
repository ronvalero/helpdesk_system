<table>
<tr>
<td><a href = "request_list.php">Request List</a></td><td><a href = "cancelled_request.php">Cancelled Request</a></td><td><a href = "deleted_request.php">Deleted Request</a></td><td><a href = "profile.php">My Profile</a></td><td><a href = "logout.php">Logout</a></td>
</tr>
</table>