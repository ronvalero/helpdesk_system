<?php
include('config.php');
$con = mysqli_connect($host,$user,$pass,$database);